<?php $__env->startSection('content'); ?>
    <br>
    <h2 align="center">کاربران</h2>
    <hr>
    <table class="table table-bordered">
        <thead class="thead-light">
        <tr>
            <th scope="col">نام</th>
            <th scope="col">نام خانوادگی</th>
            <th scope="col">شماره تلفن</th>
            <th scope="col">آدرس ایمیل</th>
            <th scope="col">شماره شناسنامه</th>
            <th scope="col">مقام</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->family); ?></td>
                <td><?php echo e($user->phonenumber); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->shenasname); ?></td>
                <td><?php echo e($user->level); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($users->render()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>