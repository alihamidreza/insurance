<?php $__env->startSection('content'); ?>
    <main class="py-4">
        <div class="row">
            <div class="container">
                <div class="card">
                    <div class="card-header" style="text-align: right">
                        ثبت نام
                    </div>
                    <div class="card-body">

                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>