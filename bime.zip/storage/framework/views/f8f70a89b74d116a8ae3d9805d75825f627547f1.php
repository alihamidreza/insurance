<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card" style="direction: rtl !important;text-align: right !important;">
            <div class="card-header bg-light">
                <span class="float-right">اضافه کردن بیمه نامه</span>
            </div>
            <div class="card-body">
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <br>
                <form action="<?php echo e(route('insurances.store')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="name">نوع بیمه نامه</label>
                        <input type="text" name="name" class="form-control" id="name" aria-describedby="nameHelp" required value="<?php echo e(old('name')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="nameCreator">نام بیمه گزار</label>
                        <input type="text" name="nameCreator" class="form-control" id="exampleInputPassword1" required value="<?php echo e(old('nameCreator')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="familyCreator">نام خانوادگی</label>
                        <input type="text" name="familyCreator" class="form-control" id="exampleInputPassword1" required value="<?php echo e(old('familyCreator')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="typeCar">نوع ماشین</label>
                        <input type="text" name="typeCar" class="form-control" id="exampleInputPassword1" required value="<?php echo e(old('typeCar')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="nameCar">نام خودرو</label>
                        <input type="text" name="nameCar" class="form-control" id="exampleInputPassword1" required value="<?php echo e(old('nameCar')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="modelCar">مدل خودرو</label>
                        <input type="text" name="modelCar" class="form-control" id="exampleInputPassword1" required value="<?php echo e(old('modelCar')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="createdYear">سال تولید خودرو</label>
                        <input type="number" name="createdYear" class="form-control" id="exampleInputPassword1" required value="<?php echo e(old('createdYear')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="number">شماره موتور</label>
                        <input type="number" name="number" class="form-control" id="exampleInputPassword1" required value="<?php echo e(old('number')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="VIN">کد VIN</label>
                        <input type="number" name="VIN" class="form-control" id="exampleInputPassword1" required value="<?php echo e(old('VIN')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="startInsurance">تاریخ شروع بیمه</label>
                        <input type="date" name="startInsurance" class="form-control" id="exampleInputPassword1" required value="<?php echo e(old('startInsurance')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="endInsurance">تاریخ انقضاء بیمه</label>
                        <input type="date" name="endInsurance" class="form-control" id="exampleInputPassword1" required value="<?php echo e(old('endInsurance')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="price"> قیمت بیمه نامه | تومان</label>
                        <input type="price" name="price" class="form-control" id="exampleInputPassword1" required value="<?php echo e(old('price')); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">اضافه کردن</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>