<?php $__env->startSection('content'); ?>

    <br><br>

    <?php if(auth()->check()): ?>

        <main class="py-4" style="direction: rtl;text-align: right;">
            <div class="row">
                <div class="container">
                    <div class="card col-md-12">
                        <div class="card-header row">اضافه کردن بیمه</div>
                        <div class="card-body">
                            <div class="form-group">
                                <label for="yourInsurance" class="row">بیمه های شما:</label>
                                <?php if(count(auth()->user()->insurances) == 0): ?>
                                    <span class="badge badge-danger p-2 pr-5 pl-5">شما بیمه ای ندارید</span>
                                <?php else: ?>
                                    <?php $__currentLoopData = auth()->user()->insurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge badge-light p-2 pr-5 pl-5"><?php echo e($insurance->name); ?></span>
                                        <?php if(! $loop->last): ?>
                                            ,
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <br>
                            <div class="row bg-light" style="height: 1px;"></div>
                            <br>
                            <div class="form-group">
                                <?php if(count($errors) > 0): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <?php if(session('noPrice')): ?>
                                    <div class="alert alert-danger">
                                        <?php echo e(session('noPrice')); ?>

                                    </div>
                                <?php endif; ?>

                                <?php if(session('failed')): ?>
                                    <div class="alert alert-danger">
                                        <?php echo e(session('failed')); ?>

                                    </div>
                                <?php endif; ?>

                                <?php if(session('cancel')): ?>
                                    <div class="alert alert-warning">
                                        <?php echo e(session('cancel')); ?>

                                    </div>
                                <?php endif; ?>

                                <?php if(session('exist')): ?>
                                    <div class="alert alert-warning">
                                        <?php echo e(session('exist')); ?>

                                    </div>
                                <?php endif; ?>

                                <?php if(session('success')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>

                                <form action="/insurance/payment" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <label for="insurance">اضافه کردن بیمه نامه:</label>
                                    <select name="insurance" id="insurance" class="form-control">
                                        <option value="" selected disabled>بیمه مورد نظر را انتخاب کنید</option>
                                        <?php $__currentLoopData = $insurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($insurance->id); ?>" name="incop">  <?php echo e($insurance->name); ?>

                                                | <?php echo e($insurance->price); ?> تومان
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <br>
                                    <button type="submit" class="btn btn-sm btn-success">خرید بیمه نامه</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

    <?php else: ?>

        <main class="py-4">
            <div class="row">
                <div class="container">
                    <div class="card col-md-12">
                        <div class="card-header row"></div>
                        <div class="card-body">
                            <div class="form-group" style="direction: rtl;text-align: right;">
                                <div class="alert alert-danger">شما برای اضافه کردن بیمه باید وارد سایت شوید;</div>
                                <br>
                                <a href="/register" class="btn btn-outline-secondary">ثبت نام</a>
                                <a href="/login" class="btn btn-outline-success">ورود</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>