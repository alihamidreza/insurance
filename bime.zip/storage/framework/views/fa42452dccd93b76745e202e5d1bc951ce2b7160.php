<?php $__env->startSection('content'); ?>


    <table class="table table-bordered table-responsive-sm">
        <thead class="thead-light">
        <tr>
            <th scope="col">نوع بیمه نامه</th>
            <th scope="col">نام بیمه گزار</th>
            <th scope="col">نام خانوادگی</th>
            <th scope="col">نوع ماشین</th>
            <th scope="col">نام خودرو</th>
            <th scope="col">مدل خودرو</th>
            <th scope="col">سال تولید خودرو</th>
            <th scope="col">شماره موتور</th>
            <th scope="col">کد VIN</th>
            <th scope="col">تاریخ شروع بیمه</th>
            <th scope="col">تاریخ انقضاء بیمه</th>
            <th scope="col">قیمت</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $insurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($insurance->name); ?></td>
                <td><?php echo e($insurance->nameCreator); ?></td>
                <td><?php echo e($insurance->familyCreator); ?></td>
                <td><?php echo e($insurance->typeCar); ?></td>
                <td><?php echo e($insurance->nameCar); ?></td>
                <td><?php echo e($insurance->modelCar); ?></td>
                <td><?php echo e($insurance->createdYear); ?></td>
                <td><?php echo e($insurance->number); ?></td>
                <td><?php echo e($insurance->VIN); ?></td>
                <td><?php echo e($insurance->startInsurance); ?></td>
                <td><?php echo e($insurance->endInsurance); ?></td>
                <td><?php echo e($insurance->price); ?> تومان</td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.pdf', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>