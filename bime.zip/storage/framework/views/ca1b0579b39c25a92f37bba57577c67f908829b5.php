<?php $__env->startSection('content'); ?>
    <br>
        <div class="btn btn-group">
            <a href="/panel/pdf" class="btn btn-sm btn-secondary"><i class="fa fa-download"></i>  PDF دانلود </a>
            <a href="/panel/all" target="_blank" class="btn btn-sm btn-info"><i class="fa fa-print"></i> Print</a>
        </div>
    <hr>
    <div class="page-break">
        <table class="table table-bordered">
            <thead class="thead-light">
            <tr>
                <th scope="col">نام</th>
                <th scope="col">نام خانوادگی</th>
                <th scope="col">شماره تلفن</th>
                <th scope="col">آدرس ایمیل</th>
                <th scope="col">شماره شناسنامه</th>
                <th scope="col">بیمه نامه کاربر</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->family); ?></td>
                    <td><?php echo e($user->phonenumber); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->shenasname); ?></td>
                    <td>
                        <?php if(count($user->insurances) == 0): ?>
                            ندارد
                        <?php endif; ?>
                        <?php $__currentLoopData = $user->insurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($insurance->name); ?><?php if(!$loop->last): ?><?php echo e(" , "); ?><?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($users->render()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>