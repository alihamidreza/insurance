<?php $__env->startSection('content'); ?>
    <br>
    <h2 align="center">بیمه نامه ها</h2>
    <a href="<?php echo e(route('insurances.create')); ?>" class="btn btn-primary btn-sm">اضافه کردن بیمه نامه</a>
    <a href="/panel/downloadInsurance" target="_blank" class="btn btn-sm btn-secondary"><i class="fa fa-print"></i> Print</a>
    <hr>
    <table class="table table-bordered table-responsive-sm">
        <thead class="thead-light">
        <tr>
            <th scope="col">نوع بیمه نامه</th>
            <th scope="col">نام بیمه گزار</th>
            <th scope="col">نام خانوادگی</th>
            <th scope="col">نوع ماشین</th>
            <th scope="col">نام خودرو</th>
            <th scope="col">مدل خودرو</th>
            <th scope="col">سال تولید خودرو</th>
            <th scope="col">شماره موتور</th>
            <th scope="col">کد VIN</th>
            <th scope="col">تاریخ شروع بیمه</th>
            <th scope="col">تاریخ انقضاء بیمه</th>
            <th scope="col">قیمت</th>
            <th scope="col">تنظیمات</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $insurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($insurance->name); ?></td>
                <td><?php echo e($insurance->nameCreator); ?></td>
                <td><?php echo e($insurance->familyCreator); ?></td>
                <td><?php echo e($insurance->typeCar); ?></td>
                <td><?php echo e($insurance->nameCar); ?></td>
                <td><?php echo e($insurance->modelCar); ?></td>
                <td><?php echo e($insurance->createdYear); ?></td>
                <td><?php echo e($insurance->number); ?></td>
                <td><?php echo e($insurance->VIN); ?></td>
                <td><?php echo e($insurance->startInsurance); ?></td>
                <td><?php echo e($insurance->endInsurance); ?></td>
                <td><?php echo e($insurance->price); ?> تومان</td>
                <td>
                    <div class="btn-group" role="group">
                        <form action="<?php echo e(route('insurances.destroy' , $insurance->id)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <button class="btn btn-danger btn-sm" type="submit" style="border-top-right-radius:0;border-bottom-right-radius: 0; ">حذف</button>
                        </form>
                        <a href="<?php echo e(route('insurances.edit' , $insurance->id)); ?>" class="btn btn-warning btn-sm">ویرایش</a>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($insurances->render()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>