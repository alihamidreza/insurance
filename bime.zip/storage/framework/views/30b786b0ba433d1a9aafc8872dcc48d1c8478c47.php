
<nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
    
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="dropdown show">
            <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="fa fa-navicon"></span>
            </a>
            <div class="dropdown-menu menudrop" aria-labelledby="dropdownMenuLink">
                <a class="dropdown-item" href="/panel">صفحه اصلی</a>
                <a class="dropdown-item" href="/panel/users">کاربران</a>
                <a class="dropdown-item" href="/panel/users">بیمه</a>
            </div>
        </div>
    </nav>
</nav>