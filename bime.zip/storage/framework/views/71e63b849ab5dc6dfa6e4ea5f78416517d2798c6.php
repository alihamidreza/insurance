<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>بیمه امن</title>
    <link href="/css/style.css" rel="stylesheet" type="text/css">
    <link href="/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="/css/bootstrap.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="/css/iranSans.css">
</head>

<body>
<script type="text/javascript" src="/js/bootstrap.js"></script>
<script type="text/javascript" src="/js/jquery-3.3.1.js"></script>

<?php echo $__env->make('section.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('section.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
</html>
