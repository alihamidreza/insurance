@extends('Admin.master')

@section('content')
    <br>
    <div class="container">

    </div>

@endsection