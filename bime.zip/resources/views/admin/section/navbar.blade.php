
<nav class="col-md-2 d-none d-md-block bg-light sidebar mt-3">
    <div class="sidebar-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="/panel">
                    <span data-feather="home" class="fa fa-home"></span>
                    صفحه اصلی <span class="sr-only">(current)</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/panel/users">
                    <span data-feather="file" class="fa fa-users"></span>
                    کاربران
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/panel/insurances">
                    <span data-feather="shopping-cart" class="fa fa-paperclip"></span>
                    بیمه
                </a>
            </li>
        </ul>
    </div>
</nav>