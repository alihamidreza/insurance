@extends('master')

@section('content')
    <main class="py-4">
        <div class="row">
            <div class="container">
                <div class="card">
                    <div class="card-header" style="text-align: right">
                        ثبت نام
                    </div>
                    <div class="card-body">

                    </div>
                </div>
            </div>
        </div>
    </main>
@endsection
