<div class="clear"></div>


<div class="row footer">
    <div class="col-sm">
        <h5>ارتباط با ما</h5>
        <hr>
        <p>آدرس: میدان ولیعصر ، بلوار کشاورز ، پلاک 68 </p><br>
        <p>تلفن تماس: 02122222</p><br>
        <p>نمابر: 02133333</p>
    </div>
    <div class="col-sm">
        <h5>مراکز فروش</h5>
        <hr>
        <p><a href="#">نمایندگی های فعال</a></p><br>
        <p><a href="#">نمایندگی های غیر فعال</a></p><br>
        <p><a href="#">تمامی شعب</a></p>
    </div>
    <div class="col-sm">
        <h5>دسترسی سریع</h5>
        <hr>
        <p><a href="#">خانه</a></p><br>
        <p><a href="#">ثبتنام/ورود</a></p><br>
        <p><a href="#">ارتباط با ما</a></p>
    </div>
</div>

<div class="clear"></div>

<div class="row copy">
    <p>کلیه حقوق مربوط به <a href="#">بیمه امن </a>محفوظ است.</p>
</div>